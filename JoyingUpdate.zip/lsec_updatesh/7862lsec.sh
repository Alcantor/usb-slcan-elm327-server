#!/system/bin/sh

echo >> "/oem/app/skipkillapp.prop"
echo "com.clusterrr.slcan2elm327 = -14" >> "/oem/app/skipkillapp.prop"

